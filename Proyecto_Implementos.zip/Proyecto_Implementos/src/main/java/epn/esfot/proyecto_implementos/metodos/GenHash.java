package epn.esfot.proyecto_implementos.metodos;

import org.mindrot.jbcrypt.BCrypt;

public class GenHash {
    public String Hash(String pass){
        return BCrypt.hashpw(pass,BCrypt.gensalt());
    }
    public boolean verificar (String pass, String hash){
        try {
            return BCrypt.checkpw(pass, hash);
        } catch (Exception e) {
            return false;
        }
    }
}
