package epn.esfot.proyecto_implementos.metodos;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/implementos_deportivos";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASS = "";

    public Connection conectarMySQL() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
        } catch (Exception e) {
            System.err.println("Error al conectar con la base de datos: " + e.getMessage());
            throw new RuntimeException("No se pudo conectar a la base de datos", e);
        }
        return conn;
    }
}