package epn.esfot.proyecto_implementos;

import epn.esfot.proyecto_implementos.metodos.GenHash;
import epn.esfot.proyecto_implementos.metodos.ImplCrud;
import epn.esfot.proyecto_implementos.metodos.Implemento;
import epn.esfot.proyecto_implementos.metodos.Usuario;
import epn.esfot.proyecto_implementos.servicio.Servicio;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class CrearController {
    @FXML private TextField txtNombre, txtCorreo, txtTelefono, txtPass;

    Servicio servicio = new Servicio();
    GenHash hash = new GenHash();

    @FXML public void agregar(){
        try{
        Usuario usuario = new Usuario(
                txtNombre.getText(),
                txtCorreo.getText(),
                txtTelefono.getText(),
                hash.Hash(txtPass.getText()),
                "Cliente");
        servicio.agregarUsuario(usuario);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Usuario agregado");
        alert.setHeaderText("Usuario agregado");
        alert.setContentText("Usuario agregado con exito, puede volver al inicio");
        alert.showAndWait();

        } catch(Exception e){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Error");
            alert.setContentText("Error al agregar usuario");
            alert.showAndWait();
        }
    }
    @FXML
    public void cerrar(ActionEvent event) {
        Stage stage = (Stage) txtNombre.getScene().getWindow();
        stage.close();
    }

}
