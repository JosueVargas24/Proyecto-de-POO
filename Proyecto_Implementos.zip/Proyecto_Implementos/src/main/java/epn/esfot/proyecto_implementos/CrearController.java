package epn.esfot.proyecto_implementos;

import epn.esfot.proyecto_implementos.metodos.GenHash;
import epn.esfot.proyecto_implementos.metodos.Usuario;
import epn.esfot.proyecto_implementos.servicio.Servicio;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class CrearController {
    @FXML private TextField txtNombre, txtCorreo, txtTelefono, txtPass;

    Servicio servicio = new Servicio();
    GenHash hash = new GenHash();

    @FXML
    public void agregar(){
        // isBlank = campo vacio
        if (txtNombre.getText().isBlank() || txtCorreo.getText().isBlank()
                || txtTelefono.getText().isBlank() || txtPass.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Campos incompletos");
            alert.setHeaderText("Todos los campos son obligatorios");
            alert.showAndWait();
            return;
        }
        // contains = si contiene "@" para los correos
        if (!txtCorreo.getText().contains("@")) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Correo invalido");
            alert.setHeaderText("El correo debe contener @");
            alert.showAndWait();
            return;
        }
        // length = mayor a tanto digitos
        if (txtTelefono.getText().length() > 10) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Telefono invalido");
            alert.setHeaderText("El Telefono no debe superar mas de 10 digitos");
            alert.showAndWait();
            return;
        }
        // matches "\\d+" - acepta unicamente digitos
        if (!txtTelefono.getText().matches("\\d+")) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Telefono invalido");
            alert.setHeaderText("El telefono solo debe contener numeros");
            alert.showAndWait();
            return;
        }
        // ningun campo podra insertar mas de 50 digitos y correo mas de 75
        if (txtNombre.getText().length() > 50 || txtCorreo.getText().length() > 75) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Campo demasiado largo");
            alert.setHeaderText("El nombre no debe superar 50 caracteres y el correo no debe superar 75");
            alert.showAndWait();
            return;
        }


        String passwordRegex = "^(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>/?]).{8,15}$";
        //(?=.*[0-9]) significa que debera tener al menos un numero
        //(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>/?]) significa que debera tener al menos un simbolo de los listados
        //{8,15} minimo 8 caracteres max 15
        //[a-zA-Z]) minimo contener una letra ya sea mayuscula o minuscula
        if (!txtPass.getText().matches(passwordRegex)) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Contraseña invalida");
            alert.setHeaderText("La contraseña debe tener minimo 8 y 15 caracteres, entre numeros, simbolos y letras");
            alert.showAndWait();
            return;
        }

        //verificar correos para evitar duplicados (al final por ser consulta a la BD)
        if (servicio.obtenerUsuarioPorCorreo(txtCorreo.getText()) != null) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Correo ya registrado");
            alert.setHeaderText("Ya existe un usuario con ese correo");
            alert.showAndWait();
            return;
        }

        try {
            Usuario usuario = new Usuario(
                    txtNombre.getText().toLowerCase(),
                    txtCorreo.getText(),
                    txtTelefono.getText(),
                    hash.hash(txtPass.getText()),
                    "Estudiante");
            servicio.agregarUsuario(usuario);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Usuario agregado");
            alert.setHeaderText("Usuario agregado");
            alert.setContentText("Usuario agregado con exito, puede volver al inicio");
            alert.showAndWait();
            // cerramos la ventana de registro y volvemos a mostrar el login que estaba detras
            Stage stage = (Stage) txtNombre.getScene().getWindow();
            stage.close();
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Error");
            alert.setContentText("Error al agregar usuario: " + e.getMessage());
            alert.showAndWait();
        }
    }
    @FXML
    public void cerrar(ActionEvent event) {
        Stage stage = (Stage) txtNombre.getScene().getWindow();
        stage.close();
    }


    //CREACION DE ADMIN
//    public static void main(String[] args) {
//        String hash = BCrypt.hashpw("Admin123!", BCrypt.gensalt());
//        System.out.println(hash);
//    }

}
