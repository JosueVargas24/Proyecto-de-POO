package epn.esfot.proyecto_implementos.metodos;

import java.sql.*;
import java.util.LinkedHashMap;
import java.util.Map;

public class ImplCrud implements Crud {
    private Connection getConnection() throws SQLException {
        Conexion miConexion = new Conexion();
        Connection conn=miConexion.conectarMySQL();
        if(conn==null){
            throw new SQLException("Error al establecer la conexion");
        }
        return conn;
    };

    @Override
    public Map<Integer, Implemento> listarTodo() {
        Map<Integer, Implemento> map = new LinkedHashMap<Integer, Implemento>();
        try {
            Connection conn=this.getConnection();
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery("SELECT * from implemento");
            while (rs.next()){
                Implemento i=new Implemento(
                        rs.getInt("id"),
                        rs.getString("codigo"),
                        rs.getString("categoria"),
                        rs.getString("nombre"),
                        rs.getString("deporte"),
                        rs.getInt("cantidad")
                );
                map.put(rs.getInt("id"), i);
            }
        } catch (Exception e) {
            throw new RuntimeException("no se pudo acceder al listar implemento");
        }
        return map;
    }

    @Override
    public Implemento buscar(String codigo) {
        Implemento implemento=null;
        String sql="SELECT * FROM implemento WHERE codigo=?";
        try (Connection conn=getConnection();
             PreparedStatement stmt=conn.prepareStatement(sql)){
            stmt.setString(1, codigo);
            try (ResultSet rs=stmt.executeQuery()){
                if(rs.next()){
                    implemento = new Implemento(
                            rs.getInt("id"),
                            rs.getString("codigo"),
                            rs.getString("categoria"),
                            rs.getString("nombre"),
                            rs.getString("deporte"),
                            rs.getInt("cantidad")
                    );
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return implemento;
    }

    @Override
    public void agregar(Implemento implemento) {
        String INSERT="INSERT INTO implemento(codigo, categoria, nombre, deporte, cantidad) VALUES(?,?,?,?,?)";
        try (Connection conn=getConnection();
             PreparedStatement stmt=conn.prepareStatement(INSERT)){
            stmt.setString(1, implemento.getCodigo());
            stmt.setString(2, implemento.getCategoria());
            stmt.setString(3, implemento.getNombre());
            stmt.setString(4, implemento.getDeporte());
            stmt.setInt(5, implemento.getCantidad());
            stmt.executeUpdate();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void eliminar(int id) {
        String DELETE="DELETE FROM implemento WHERE id=?";
        try {
            Connection conn=this.getConnection();
            PreparedStatement pstmt=conn.prepareStatement(DELETE);
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void editar(Implemento implemento) {
        String UPDATE="UPDATE implemento SET categoria=?, nombre=?, deporte=?, cantidad=? WHERE codigo=?";
        try {
            Connection conn=this.getConnection();
            PreparedStatement pstmt=conn.prepareStatement(UPDATE);
            pstmt.setString(1, implemento.getCategoria());
            pstmt.setString(2, implemento.getNombre());
            pstmt.setString(3, implemento.getDeporte());
            pstmt.setInt(4, implemento.getCantidad());
            pstmt.setString(5, implemento.getCodigo());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public Usuario obtenerUsuario(String nombre) {
        Usuario usuario=null;
        String sql="SELECT * FROM usuario WHERE nombre=?";
        try (Connection conn=getConnection();
             PreparedStatement stmt=conn.prepareStatement(sql)){
            stmt.setString(1, nombre);
            try (ResultSet rs=stmt.executeQuery()){
                if(rs.next()){
                    usuario = new Usuario(
                            rs.getInt("id"),
                            rs.getString("nombre"),
                            rs.getString("correo"),
                            rs.getString("telefono"),
                            rs.getString("contrasenia"),
                            rs.getString("tipo")
                    );
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return usuario;
    }
    @Override
    public void agregarUsuario(Usuario usuario) {
        String INSERT="INSERT INTO usuario(nombre, correo, telefono, contrasenia, tipo) VALUES(?,?,?,?,?)";
        try (Connection conn=getConnection();
             PreparedStatement stmt=conn.prepareStatement(INSERT)){
            stmt.setString(1, usuario.getNombre());
            stmt.setString(2, usuario.getCorreo());
            stmt.setString(3, usuario.getTelefono());
            stmt.setString(4, usuario.getContrasenia());
            stmt.setString(5, usuario.getTipo());
            stmt.executeUpdate();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}








