package epn.esfot.proyecto_implementos;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {
    @FXML
    private TextField txtCorreo;
    @FXML
    private PasswordField txtPass;
    @FXML
    private ComboBox<String> cmbRol;
    @FXML
    public void initialize(){
        cmbRol.getItems().addAll("Administrador", "Cliente", "Invitado");
    }

    @FXML
    public void inicio(ActionEvent event) {
        if(cmbRol.getValue().equals("Administrador")&& cmbRol.getValue()!=null&&txtCorreo.getText().equals("a")&& txtPass.getText().equals("123")){
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Crud.fxml"));
                Parent root = fxmlLoader.load();
                Stage stage = new Stage();
                stage.setTitle("IMPLEMENTOS");
                stage.setScene(new Scene(root));
                stage.show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (cmbRol.getValue().equals("Cliente")&& cmbRol.getValue()!=null&&
                txtCorreo.getText().equals("c")
                && txtPass.getText().equals("123")) {
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Crud.fxml"));
                Parent root = fxmlLoader.load();
                Stage stage = new Stage();
                stage.setTitle("IMPLEMENTOS");
                stage.setScene(new Scene(root));
                stage.show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (cmbRol.getValue().equals("Invitado")&& cmbRol.getValue()!=null) {
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Crud.fxml"));
                Parent root = fxmlLoader.load();
                Stage stage = new Stage();
                stage.setTitle("IMPLEMENTOS");
                stage.setScene(new Scene(root));
                stage.show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText(null);
            alert.setContentText("Error al ingresar el correo o la contraseña");
            alert.showAndWait();
        }
    }
    @FXML
    public void registro(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Crear.fxml"));
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("REGISTRO");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}