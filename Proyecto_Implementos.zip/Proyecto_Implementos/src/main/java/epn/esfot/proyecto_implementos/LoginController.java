package epn.esfot.proyecto_implementos;

import epn.esfot.proyecto_implementos.metodos.GenHash;
import epn.esfot.proyecto_implementos.metodos.Usuario;
import epn.esfot.proyecto_implementos.servicio.Servicio;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {
    @FXML
    private TextField txtCorreo;
    @FXML
    private PasswordField txtPass;
    @FXML
    private ComboBox<String> cmbRol;
    @FXML
    private Button btnSalir;

    private Servicio servicio = new Servicio();
    private GenHash hash = new GenHash();

    @FXML
    public void initialize(){
        cmbRol.getItems().addAll("Administrador", "Estudiante", "Invitado");
    }

    @FXML
    public void inicio(ActionEvent event) {
        String rolSeleccionado = cmbRol.getValue();

        if (rolSeleccionado == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Rol no seleccionado");
            alert.setHeaderText("Debe seleccionar un rol antes de ingresar");
            alert.showAndWait();
            return;
        }

        if (rolSeleccionado.equals("Invitado")) {
            abrirCrud("Invitado");
            return;
        }

        if (txtCorreo.getText().isBlank() || txtPass.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Campos incompletos");
            alert.setHeaderText("Debe ingresar correo y contraseña");
            alert.showAndWait();
            return;
        }

        Usuario usuario = servicio.obtenerUsuarioPorCorreo(txtCorreo.getText());

        if (usuario == null || !hash.verificar(txtPass.getText(), usuario.getContrasenia())) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText(null);
            alert.setContentText("Correo o contraseña incorrectos");
            alert.showAndWait();
            return;
        }

        if (!usuario.getTipo().equalsIgnoreCase(rolSeleccionado)) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText(null);
            alert.setContentText("El rol seleccionado no coincide con el usuario");
            alert.showAndWait();
            return;
        }

        abrirCrud(usuario.getTipo());
    }

    private void abrirCrud(String rol) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Aplicacion.class.getResource("Crud.fxml"));
            Parent root = fxmlLoader.load();

            CrudController crudController = fxmlLoader.getController();
            crudController.setRolActual(rol);

            Stage stage = new Stage();
            stage.setTitle("IMPLEMENTOS");
            stage.setScene(new Scene(root));
            stage.show();

            Stage loginStage = (Stage) cmbRol.getScene().getWindow();
            loginStage.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void registro(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Aplicacion.class.getResource("Crear.fxml"));
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("REGISTRO");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void salirAplicacion() {
        Stage stage = (Stage) btnSalir.getScene().getWindow();
        stage.close();
    }
}