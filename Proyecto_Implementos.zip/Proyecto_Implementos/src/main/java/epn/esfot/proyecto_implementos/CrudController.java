package epn.esfot.proyecto_implementos;
import epn.esfot.proyecto_implementos.metodos.Implemento;
import epn.esfot.proyecto_implementos.servicio.Servicio;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.Map;

public class CrudController {
    @FXML
    private TextField txtId;
    @FXML
    private TextField txtCodigo;
    @FXML
    private TextField txtNombre;
    @FXML
    private TextField txtCategoria;
    @FXML
    private TextField txtDeporte;
    @FXML
    private TextField txtCantidad;
    @FXML
    private TableView<Implemento> tblImplementos;
    @FXML private TableColumn<Implemento, Integer> colId;
    @FXML private TableColumn<Implemento, String> colNombre;
    @FXML private TableColumn<Implemento, String> colCategoria;
    @FXML private TableColumn<Implemento, String> colDeporte;
    @FXML private TableColumn<Implemento, Integer> colCantidad;
    @FXML private TableColumn<Implemento, String> colCodigo;

    private Servicio servicio=new Servicio();
    @FXML
    public void initialize(){
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colCodigo.setCellValueFactory(new PropertyValueFactory<>("codigo"));
        colCategoria.setCellValueFactory(new PropertyValueFactory<>("categoria"));
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colDeporte.setCellValueFactory(new PropertyValueFactory<>("deporte"));
        colCantidad.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
        mostrarProductos();
        tblImplementos.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSelection, newSelection) -> {
                    if (newSelection != null) {
                        llenarCampos(newSelection);
                    }
                }
        );
    }
    @FXML
    private void llenarCampos(Implemento implemento) {
        txtId.setText(String.valueOf(implemento.getId()));
        txtCodigo.setText(implemento.getCodigo());
        txtCategoria.setText(implemento.getCategoria());
        txtNombre.setText(implemento.getNombre());
        txtDeporte.setText(implemento.getDeporte());
        txtCantidad.setText(String.valueOf(implemento.getCantidad()));
    }
    @FXML
    public void mostrarProductos(){
        try {
            Map<Integer, Implemento> inventario = servicio.listarTodo();
            ObservableList<Implemento> lista = FXCollections.observableArrayList(inventario.values());
            tblImplementos.setItems(lista);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @FXML
    public void insertar(){
        try {
            Implemento i = new Implemento (
                    txtCodigo.getText(),
                    txtCategoria.getText(),
                    txtNombre.getText(),
                    txtDeporte.getText(),
                    Integer.parseInt(txtCantidad.getText())
            );
            servicio.agregar(i);
            mostrarProductos();
            limpiarCampos();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    public void actualizar(){
        try {
            Implemento i = new Implemento (
                    Integer.parseInt(txtCantidad.getText()),
                    txtCodigo.getText(),
                    txtCategoria.getText(),
                    txtNombre.getText(),
                    txtDeporte.getText(),
                    Integer.parseInt(txtCantidad.getText())
            );
            servicio.editar(i);
            mostrarProductos();
            limpiarCampos();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    @FXML
    public void eliminar(){
        try {
            servicio.eliminar(Integer.parseInt(txtCantidad.getText()));
            mostrarProductos();
            limpiarCampos();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    @FXML
    public void buscar(){
        try {
            Implemento i=servicio.buscar(txtCodigo.getText());
            txtId.setText(String.valueOf(i.getId()));
            txtNombre.setText(i.getNombre());
            txtCategoria.setText(i.getCategoria());
            txtDeporte.setText(i.getDeporte());
            txtCantidad.setText(String.valueOf(i.getCantidad()));

            mostrarProductos();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    public void limpiarCampos(){
        txtCodigo.clear();
        txtCategoria.clear();
        txtNombre.clear();
        txtDeporte.clear();
        txtCantidad.clear();
        txtId.clear();
    }

}
