package epn.esfot.proyecto_implementos;
import epn.esfot.proyecto_implementos.metodos.Implemento;
import epn.esfot.proyecto_implementos.servicio.Servicio;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Map;

public class CrudController {

    @FXML
    private TextField txtCodigo;
    @FXML
    private TextField txtNombre;
    @FXML
    private TextField txtCategoria;
    @FXML
    private TextField txtDeporte;
    @FXML
    private TextField txtCantidad;
    @FXML
    private TableView<Implemento> tblImplementos;
    @FXML private TableColumn<Implemento, Integer> colId;
    @FXML private TableColumn<Implemento, String> colNombre;
    @FXML private TableColumn<Implemento, String> colCategoria;
    @FXML private TableColumn<Implemento, String> colDeporte;
    @FXML private TableColumn<Implemento, Integer> colCantidad;
    @FXML private TableColumn<Implemento, String> colCodigo;

    @FXML private Button btnAgregar;
    @FXML private Button btnActualizar;
    @FXML private Button btnEliminar;

    private Servicio servicio = new Servicio();
    private String rolActual;

    @FXML
    public void initialize(){
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colCodigo.setCellValueFactory(new PropertyValueFactory<>("codigo"));
        colCategoria.setCellValueFactory(new PropertyValueFactory<>("categoria"));
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colDeporte.setCellValueFactory(new PropertyValueFactory<>("deporte"));
        colCantidad.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
        mostrarProductos();
        tblImplementos.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSelection, newSelection) -> {
                    if (newSelection != null) {
                        llenarCampos(newSelection);
                    }
                }
        );
    }

    public void setRolActual(String rol) {
        this.rolActual = rol;
        aplicarPermisos();
    }

    private void aplicarPermisos() {
        if (rolActual == null) return;

        switch (rolActual) {
            case "Administrador" -> {
                btnAgregar.setDisable(false);
                btnActualizar.setDisable(false);
                btnEliminar.setDisable(false);
            }
            case "Estudiante" -> {
                btnAgregar.setDisable(false);
                btnActualizar.setDisable(true);
                btnEliminar.setDisable(true);
            }
            case "Invitado" -> {
                btnAgregar.setDisable(true);
                btnActualizar.setDisable(true);
                btnEliminar.setDisable(true);
            }
            default -> {
                btnAgregar.setDisable(true);
                btnActualizar.setDisable(true);
                btnEliminar.setDisable(true);
            }
        }
    }

    @FXML
    private void llenarCampos(Implemento implemento) {
        txtCodigo.setText(implemento.getCodigo());
        txtCategoria.setText(implemento.getCategoria());
        txtNombre.setText(implemento.getNombre());
        txtDeporte.setText(implemento.getDeporte());
        txtCantidad.setText(String.valueOf(implemento.getCantidad()));
    }

    @FXML
    public void mostrarProductos(){
        try {
            Map<Integer, Implemento> inventario = servicio.listarTodo();
            ObservableList<Implemento> lista = FXCollections.observableArrayList(inventario.values());
            tblImplementos.setItems(lista);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void insertar(){
        if (txtCodigo.getText().isBlank() || txtCategoria.getText().isBlank()
                || txtNombre.getText().isBlank() || txtDeporte.getText().isBlank()
                || txtCantidad.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Campos incompletos");
            alert.setHeaderText("Todos los campos son obligatorios");
            alert.showAndWait();
            return;
        }

        if (txtCodigo.getText().length() > 10 || txtCategoria.getText().length() > 80
                || txtNombre.getText().length() > 80 || txtDeporte.getText().length() > 80) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Campo demasiado largo");
            alert.setHeaderText("Ningun campo puede superar los 80 caracteres");
            alert.showAndWait();
            return;
        }

        if (!txtCantidad.getText().matches("\\d+")) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Cantidad invalida");
            alert.setHeaderText("La cantidad solo debe contener numeros");
            alert.showAndWait();
            return;
        }

        int cantidad = Integer.parseInt(txtCantidad.getText());

        if (cantidad <= 0) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Cantidad invalida");
            alert.setHeaderText("La cantidad debe ser mayor a 0");
            alert.showAndWait();
            return;
        }

        try {
            Implemento i = new Implemento (
                    txtCodigo.getText(),
                    txtCategoria.getText(),
                    txtNombre.getText(),
                    txtDeporte.getText(),
                    cantidad
            );
            servicio.agregar(i);
            mostrarProductos();
            limpiarCampos();
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Error al agregar el implemento");
            alert.setContentText(e.getMessage());
            alert.showAndWait();
        }
    }

    @FXML
    public void actualizar(){
        if (txtCodigo.getText().isBlank() || txtCategoria.getText().isBlank()
                || txtNombre.getText().isBlank() || txtDeporte.getText().isBlank()
                || txtCantidad.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Campos incompletos");
            alert.setHeaderText("Todos los campos son obligatorios");
            alert.showAndWait();
            return;
        }

        if (txtCodigo.getText().length() > 10 || txtCategoria.getText().length() > 80
                || txtNombre.getText().length() > 80 || txtDeporte.getText().length() > 80) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Campo demasiado largo");
            alert.setHeaderText("Ningun campo puede superar los 80 caracteres");
            alert.showAndWait();
            return;
        }

        if (!txtCantidad.getText().matches("\\d+")) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Cantidad invalida");
            alert.setHeaderText("La cantidad solo debe contener numeros");
            alert.showAndWait();
            return;
        }

        int cantidad = Integer.parseInt(txtCantidad.getText());
        if (cantidad <= 0) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Cantidad invalida");
            alert.setHeaderText("La cantidad debe ser mayor a 0");
            alert.showAndWait();
            return;
        }

        try {
            Implemento i = new Implemento(
                    txtCodigo.getText(),
                    txtCategoria.getText(),
                    txtNombre.getText(),
                    txtDeporte.getText(),
                    cantidad
            );
            servicio.editar(i);
            mostrarProductos();
            limpiarCampos();
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Error al actualizar el implemento");
            alert.setContentText(e.getMessage());
            alert.showAndWait();
        }
    }

    @FXML
    public void eliminar(){
        try {
            servicio.eliminar(txtCodigo.getText());
            mostrarProductos();
            limpiarCampos();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    public void buscar(){
        try {
            Implemento i = servicio.buscar(txtCodigo.getText());
            if (i == null) {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("No encontrado");
                alert.setHeaderText("No existe ningun implemento con ese codigo");
                alert.showAndWait();
                limpiarCampos();
                return;
            }
            txtCodigo.setText(i.getCodigo());
            txtNombre.setText(i.getNombre());
            txtCategoria.setText(i.getCategoria());
            txtDeporte.setText(i.getDeporte());
            txtCantidad.setText(String.valueOf(i.getCantidad()));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    public void limpiarCampos(){
        txtCodigo.clear();
        txtCategoria.clear();
        txtNombre.clear();
        txtDeporte.clear();
        txtCantidad.clear();
    }

    @FXML
    public void cerrarSesion() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Aplicacion.class.getResource("Login.fxml"));
            Parent root = fxmlLoader.load();

            Stage stage = new Stage();
            stage.setTitle("LOGIN");
            stage.setScene(new Scene(root));
            stage.show();

            // Usamos otro elemento que sí exista, como txtCodigo
            Stage crudStage = (Stage) txtCodigo.getScene().getWindow();
            crudStage.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}