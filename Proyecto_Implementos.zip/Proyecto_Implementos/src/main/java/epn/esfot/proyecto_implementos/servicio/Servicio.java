package epn.esfot.proyecto_implementos.servicio;

import epn.esfot.proyecto_implementos.metodos.Crud;
import epn.esfot.proyecto_implementos.metodos.ImplCrud;
import epn.esfot.proyecto_implementos.metodos.Implemento;
import epn.esfot.proyecto_implementos.metodos.Usuario;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.util.Map;

public class Servicio {
    private Crud crud=new ImplCrud();
    public Map<Integer, Implemento> listarTodo(){
        return  crud.listarTodo();
    }
    public Implemento buscar(String codigo){
        return  crud.buscar(codigo);
    }
    public void agregar (Implemento implemento){
        crud.agregar(implemento);
    }
    public void eliminar (int id){
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("WARNING");
        alert.setHeaderText("¿Esta seguro que desea eliminar el implemento deportivo?");
        alert.setContentText("Esta accion no se puede deshacer");
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                crud.eliminar(id);
                Alert alert2 = new Alert(Alert.AlertType.INFORMATION);
                alert2.setTitle("Exito");
                alert2.setHeaderText("Implemento eliminado");
                alert2.showAndWait();
            } else  {
                Alert alert3 = new Alert(Alert.AlertType.INFORMATION);
                alert3.setTitle("Operacion cancelada");
                alert3.setHeaderText("El implemento no ha sido eliminado");
            }
        });
    }
    public void editar (Implemento implemento){
        crud.editar(implemento);
    }
    public Usuario obtenerUsuario (String nombre){
        return  crud.obtenerUsuario(nombre);
    }
    public void agregarUsuario (Usuario usuario){crud.agregarUsuario(usuario);}
}
