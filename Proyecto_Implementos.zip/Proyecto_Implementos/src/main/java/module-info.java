module epn.esfot.proyecto_implementos {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires jbcrypt;


    opens epn.esfot.proyecto_implementos to javafx.fxml;
    opens epn.esfot.proyecto_implementos.metodos to javafx.fxml;
    exports epn.esfot.proyecto_implementos;
    exports epn.esfot.proyecto_implementos.metodos;
}